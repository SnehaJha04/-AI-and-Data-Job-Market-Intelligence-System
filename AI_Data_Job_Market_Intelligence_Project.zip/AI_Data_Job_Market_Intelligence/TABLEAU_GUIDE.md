# Tableau Dashboard Guide
Connect Tableau to `data/jobs_sample.csv` or a cleaned real dataset.

## Dashboard 1: Market Overview
KPI cards: posting count, distinct roles, median salary midpoint, remote share.
Charts: postings by role, postings by location, work-mode split.
Filters: role, location, experience, work mode, posted date.

## Dashboard 2: Skills Intelligence
Split the comma-separated `skills` field into one skill per row. Build a bar chart of skill frequency and a role-vs-skill highlight table.

## Dashboard 3: Salary & Experience
Charts: salary midpoint by role/location and experience distribution by role.
Do not compare currencies or monthly/annual pay until normalized.

Calculated fields:
- Salary Midpoint: `([min_salary] + [max_salary]) / 2`
- Remote Flag: `IF LOWER([work_mode]) = "remote" THEN 1 ELSE 0 END`
- Job Count: `COUNT([job_id])`

Sample data is synthetic; use recent real postings before making market claims.
