import io, re
from pathlib import Path
import numpy as np
import pandas as pd
import plotly.express as px
import streamlit as st

st.set_page_config(page_title="AI & Data Job Market Intelligence", page_icon="📊", layout="wide")
DATA_PATH=Path(__file__).parent/"data"/"jobs_sample.csv"
ROLE_SKILLS={
"Data Analyst":["SQL","Excel","Power BI","Tableau","Python","Statistics","Data Visualization"],
"Data Scientist":["Python","SQL","Machine Learning","Statistics","Pandas","Scikit-learn","NLP"],
"Machine Learning Engineer":["Python","Machine Learning","Scikit-learn","TensorFlow","Docker","Git"],
"AI Engineer":["Python","LLM","NLP","RAG","APIs","Docker","Vector Database"],
"Data Engineer":["SQL","Python","ETL","Spark","Airflow","Cloud","Data Warehousing"],
"Business Intelligence Analyst":["SQL","Excel","Power BI","Tableau","Data Modeling"],
"NLP Engineer":["Python","NLP","Transformers","PyTorch","LLM","Vector Database"]}
SKILLS=sorted(set(x for xs in ROLE_SKILLS.values() for x in xs)|{"MySQL","Communication","Problem Solving"})

@st.cache_data
def load_sample(): return pd.read_csv(DATA_PATH)
def prepare(d):
    d=d.copy(); d.columns=[str(c).strip().lower().replace(" ","_") for c in d.columns]
    for c in ["job_title","location","skills"]:
        if c not in d.columns: raise ValueError(f"Required column missing: {c}")
    defaults={"company":"Unknown","work_mode":"Unknown","experience_level":"Unknown","min_salary":np.nan,"max_salary":np.nan,"currency":"Unknown","posted_date":"","job_description":"","source_url":"","data_type":"UPLOADED"}
    for c,v in defaults.items():
        if c not in d.columns: d[c]=v
    for c in ["min_salary","max_salary"]: d[c]=pd.to_numeric(d[c],errors="coerce")
    d["salary_midpoint"]=d[["min_salary","max_salary"]].mean(axis=1)
    d["posted_date"]=pd.to_datetime(d["posted_date"],errors="coerce")
    for c in ["job_title","location","skills","work_mode","experience_level","currency"]: d[c]=d[c].fillna("Unknown").astype(str)
    return d
def skill_counts(d):
    counts={}
    for txt in d.skills.fillna(""):
        for s in set(x.strip() for x in re.split(r"[,;|\\n]",str(txt)) if x.strip()): counts[s]=counts.get(s,0)+1
    return pd.DataFrame([{"Skill":k,"Postings mentioning skill":v} for k,v in counts.items()]).sort_values("Postings mentioning skill",ascending=False)

st.title("📊 AI and Data Job Market Intelligence")
st.write("Explore job demand, skills, salary ranges, locations, and personal skill gaps.")
with st.sidebar:
    st.header("Dataset"); uploaded=st.file_uploader("Upload job-postings CSV",type=["csv"])
    st.caption("Bundled sample data is synthetic demo data, not live vacancies.")
try:
    data=prepare(pd.read_csv(uploaded) if uploaded else load_sample())
except Exception as e:
    st.error(f"Dataset error: {e}"); st.stop()
if uploaded is None: st.warning("Demo mode: sample records are synthetic and are only for testing.")
with st.sidebar:
    st.header("Filters")
    roles=sorted(data.job_title.unique()); role_filter=st.multiselect("Job role",roles,default=roles)
    locs=sorted(data.location.unique()); loc_filter=st.multiselect("Location",locs,default=locs)
    levels=sorted(data.experience_level.unique()); level_filter=st.multiselect("Experience level",levels,default=levels)
    modes=sorted(data.work_mode.unique()); mode_filter=st.multiselect("Work mode",modes,default=modes)
f=data[data.job_title.isin(role_filter)&data.location.isin(loc_filter)&data.experience_level.isin(level_filter)&data.work_mode.isin(mode_filter)].copy()
if f.empty: st.info("No jobs match these filters. Change the sidebar filters."); st.stop()
sals=f.salary_midpoint.dropna()
a,b,c,d=st.columns(4); a.metric("Job postings",f"{len(f):,}"); b.metric("Unique roles",f"{f.job_title.nunique():,}")
c.metric("Median salary midpoint",f"₹{sals.median():,.0f}" if len(sals) else "N/A")
d.metric("Remote share",f"{f.work_mode.str.lower().eq('remote').mean()*100:.1f}%")
t1,t2,t3,t4,t5=st.tabs(["Market Overview","Skills Intelligence","Salary & Locations","Skill Gap Advisor","Data Explorer"])
with t1:
    x,y=st.columns(2)
    rc=f.job_title.value_counts().rename_axis("Job role").reset_index(name="Postings")
    mc=f.work_mode.value_counts().rename_axis("Work mode").reset_index(name="Postings")
    x.plotly_chart(px.bar(rc,x="Postings",y="Job role",orientation="h",title="Postings by role"),use_container_width=True)
    y.plotly_chart(px.pie(mc,names="Work mode",values="Postings",hole=.4,title="Work mode split"),use_container_width=True)
    ec=f.experience_level.value_counts().rename_axis("Experience").reset_index(name="Postings")
    st.plotly_chart(px.bar(ec,x="Experience",y="Postings",title="Postings by experience"),use_container_width=True)
with t2:
    sc=skill_counts(f)
    if len(sc):
        n=st.slider("Skills to display",5,min(25,len(sc)),min(12,len(sc)))
        st.plotly_chart(px.bar(sc.head(n),x="Postings mentioning skill",y="Skill",orientation="h",title="Skills mentioned"),use_container_width=True)
        st.dataframe(sc.assign(**{"Share of filtered postings (%)":(sc["Postings mentioning skill"]/len(f)*100).round(1)}),use_container_width=True,hide_index=True)
    else: st.info("No skill values found.")
with t3:
    sd=f.dropna(subset=["salary_midpoint"])
    if len(sd):
        if sd.currency.nunique()>1: st.warning("Multiple currencies detected. Normalize currencies before comparing.")
        sr=sd.groupby(["job_title","currency"],dropna=False).salary_midpoint.median().reset_index(name="Median salary midpoint")
        st.plotly_chart(px.bar(sr,x="Median salary midpoint",y="job_title",color="currency",orientation="h",title="Median salary midpoint by role"),use_container_width=True)
        ls=sd.groupby("location").salary_midpoint.median().reset_index(name="Median salary midpoint").sort_values("Median salary midpoint",ascending=False)
        st.plotly_chart(px.bar(ls,x="location",y="Median salary midpoint",title="Salary midpoint by location"),use_container_width=True)
    else: st.info("Salary values unavailable.")
    st.caption("Confirm currency and pay period before comparing salary figures.")
with t4:
    target=st.selectbox("Target role",sorted(ROLE_SKILLS)); current=st.multiselect("Skills you already have",SKILLS)
    needed=ROLE_SKILLS[target]; missing=[s for s in needed if s not in current]; have=[s for s in needed if s in current]
    x,y=st.columns(2); x.metric("Matching target skills",len(have)); y.metric("Skills to develop",len(missing))
    if missing:
        st.write("**Suggested skills:** "+", ".join(missing))
        st.dataframe(pd.DataFrame({"Learning order":range(1,len(missing)+1),"Skill":missing,"Practice task":[f"Build a small hands-on exercise using {s}." for s in missing]}),use_container_width=True,hide_index=True)
    else: st.success("You selected all suggested skills. Validate against real job descriptions.")
    st.caption("This is rule-based guidance, not a hiring prediction or employment guarantee.")
with t5:
    st.dataframe(f,use_container_width=True,hide_index=True)
    st.download_button("Download filtered CSV",f.to_csv(index=False).encode("utf-8-sig"),"filtered_job_market.csv","text/csv")
    buf=io.BytesIO()
    with pd.ExcelWriter(buf,engine="openpyxl") as w:
        f.to_excel(w,index=False,sheet_name="Filtered Jobs"); skill_counts(f).to_excel(w,index=False,sheet_name="Skill Counts")
    st.download_button("Download Excel report",buf.getvalue(),"job_market_report.xlsx","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
st.divider(); st.caption("Portfolio / academic project. Use recent, representative job data for real market conclusions.")
