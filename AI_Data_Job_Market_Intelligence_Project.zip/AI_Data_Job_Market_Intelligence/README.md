# AI and Data Job Market Intelligence System

A portfolio project combining Python, Streamlit, Excel, MySQL, Tableau, and a rule-based skill-gap advisor.

## Features
- Interactive dashboard with role/location/experience/work-mode filters
- Skill demand rankings, salary midpoint comparisons, hiring mix charts
- Skill-gap advisor for target roles
- CSV upload, filtered CSV download, Excel report download
- MySQL schema and SQL analysis queries
- Excel and Tableau guides

## Run on Windows / VS Code
1. Extract this ZIP and open the `AI_Data_Job_Market_Intelligence` folder in VS Code.
2. Terminal:
   `python -m venv .venv`
3. Activate:
   `\.venv\Scripts\Activate.ps1`
   If blocked: `Set-ExecutionPolicy -Scope Process -ExecutionPolicy RemoteSigned`, then activate again.
4. Install:
   `python -m pip install -r requirements.txt`
5. Run:
   `python -m streamlit run app.py`
6. Open the local URL shown in terminal (usually http://localhost:8501).

## Data note
The included 240 rows are synthetic demo data, not live job vacancies or verified salary observations. Upload recent, representative job data for real market insights. Required CSV fields: `job_title`, `location`, `skills`.

## MySQL
Run `sql/01_schema.sql` in MySQL Workbench, import the CSV with matching columns, then run `sql/02_analysis_queries.sql`.

## Tableau and Excel
Follow `TABLEAU_GUIDE.md` and `EXCEL_GUIDE.md`.
