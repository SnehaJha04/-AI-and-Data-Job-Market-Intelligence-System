# Excel Analysis Guide
1. Open `data/jobs_sample.csv` in Excel and save as XLSX.
2. Format data as a Table with Ctrl+T.
3. Add Salary Midpoint formula: `=AVERAGE([@[min_salary]],[@[max_salary]])`.
4. Create PivotTables: count by role, location, experience, work mode; salary midpoint by role.
5. Add slicers for role/location/experience/work mode.
6. Use conditional formatting to identify missing salaries and invalid salary ranges.
7. Sample data is synthetic and is only for practice.
