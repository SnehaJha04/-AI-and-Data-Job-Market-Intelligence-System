USE job_market_intelligence;
-- Count postings by role
SELECT job_title, COUNT(*) AS postings FROM job_postings GROUP BY job_title ORDER BY postings DESC;
-- Demand by location
SELECT location, COUNT(*) AS postings FROM job_postings GROUP BY location ORDER BY postings DESC;
-- Average salary midpoint grouped by role and currency
SELECT job_title, currency, ROUND(AVG((min_salary+max_salary)/2),0) AS avg_midpoint
FROM job_postings WHERE min_salary IS NOT NULL AND max_salary IS NOT NULL
GROUP BY job_title,currency ORDER BY avg_midpoint DESC;
-- Experience-level mix
SELECT experience_level, COUNT(*) AS postings FROM job_postings GROUP BY experience_level ORDER BY postings DESC;
-- Work mode mix
SELECT work_mode, COUNT(*) AS postings FROM job_postings GROUP BY work_mode ORDER BY postings DESC;
-- Month trend
SELECT DATE_FORMAT(posted_date,'%Y-%m') AS month, COUNT(*) AS postings
FROM job_postings WHERE posted_date IS NOT NULL GROUP BY month ORDER BY month;
-- Search postings mentioning SQL
SELECT job_title, company, location, skills FROM job_postings WHERE skills LIKE '%SQL%';
-- Basic data quality checks
SELECT COUNT(*) AS total_rows,
 SUM(job_title IS NULL OR job_title='') AS missing_titles,
 SUM(location IS NULL OR location='') AS missing_locations,
 SUM(min_salary>max_salary) AS invalid_salary_ranges
FROM job_postings;
