CREATE DATABASE IF NOT EXISTS job_market_intelligence;
USE job_market_intelligence;
CREATE TABLE IF NOT EXISTS job_postings (
 job_id INT PRIMARY KEY,
 job_title VARCHAR(150) NOT NULL,
 company VARCHAR(200),
 location VARCHAR(150),
 work_mode VARCHAR(50),
 experience_level VARCHAR(50),
 min_salary DECIMAL(14,2),
 max_salary DECIMAL(14,2),
 currency VARCHAR(10),
 skills TEXT,
 job_description TEXT,
 posted_date DATE,
 source_url TEXT,
 data_type VARCHAR(40)
);
CREATE INDEX idx_job_role ON job_postings(job_title);
CREATE INDEX idx_job_location ON job_postings(location);
